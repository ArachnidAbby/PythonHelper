#PythonHelper

##description
    This adds a few simple functions that are commonly used by me and possible a few other people. This includes everything listed in the feature list below.

##features
    ### Version 0.0.1
        -  _ModifiedTools.Input_ : adds an input method with a quit function as well as a function to add functions.
        - _Clock.Time.DeltaTime_ : adds auto time delta calculator

##links
[link to GitHub Source code!](https://github.com/spidertyler2005/PythonHelper)