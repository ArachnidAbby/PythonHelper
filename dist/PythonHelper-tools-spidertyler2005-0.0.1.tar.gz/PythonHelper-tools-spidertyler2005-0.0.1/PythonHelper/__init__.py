import PythonHelper.Clock
import PythonHelper.modifiedTools

print("Thanks for using python Helper!")